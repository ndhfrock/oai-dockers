# "@(#) $MMEfile: s1ap_s.py@@/main/d_mme/2 2008/09/23 11:04:05 $"

"""DI functions for MME S1AP-S module"""
