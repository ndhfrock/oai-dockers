
"""DI functions for MME M3AP-S module"""
