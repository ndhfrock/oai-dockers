
"""DI functions for MME M3AP-C module"""

import module_di

def getCompilationInfo():
  """Print compilation info
  Example:	getCompilationInfo()"""
  
  cinfo = module_di.getCompilationInfo()
  print cinfo

def printMCEs():
  """Print MCEs info
  Example:	printMCEs()"""
  
  module_di.printMCEs()

def printSCTPSockets():
  """Print SCTP sockets info
  Example:	printSCTPSockets()"""
  
  module_di.printSCTPSockets()

def closeSCTPSocket(sid):
  """Close SCTP socket identified by id
  Example:	closeSCTPSocket(0)"""
  
  module_di.closeSCTPSocket(sid)

def m3resetSCTPSocket(sid):
  """Send M3AP reset on SCTP socket identified by id
  Example:	m3resetSCTPSocket(0)"""
  
  module_di.m3resetSCTPSocket(sid)


