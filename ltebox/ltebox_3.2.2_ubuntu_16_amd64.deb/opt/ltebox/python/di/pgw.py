# "@(#) $SCMfile: gw.py@@/main/d_mme/9 2009/04/17 15:26:30 $"

"""DI functions for PGW module"""

import module_di

def printUeCtxList(maxDisp = module_di.getMaxUe()):
  """Displays (up to given maximum number of contexts) list of
  allocated UE contexts.
  Returns number of displayed items.
  Example:	printUeCtxList()   # print list of all allocated UE contexts
  Example:	printUeCtxList(30) # print list of first 30 allocated UE contexts"""
  
  maxUe = module_di.getMaxUe()
  nbDisp = 0
  nbFound = 0;
  
  if maxDisp > maxUe:
    maxDisp = maxUe
  
  for i in range(1, maxUe+1):
    if module_di.isUeCtxUsed(i):
       nbFound += 1
       if nbDisp < maxDisp: 
          nbDisp += module_di.printUeCtxByIndex(i)

  return nbDisp


def printBearerCtxList(maxDisp = module_di.getMaxUe() * (module_di.getMaxBearer()+1)):
  """Displays (up to given maximum number of contexts) list of
  allocated bearer contexts.
  Returns number of displayed items.
  Example:	printBearerCtxList()   # print list of all allocated bearer contexts
  Example:	printBearerCtxList(50) # print list of first 50 allocated bearer contexts"""
  
  maxBearer = module_di.getMaxUe() * (module_di.getMaxBearer()+1)
  nbDisp = 0
  nbFound = 0
  
  if maxDisp > maxBearer:
    maxDisp = maxBearer
  
  for i in range(1, maxBearer+1):
    if module_di.isBearerCtxUsed(i):
       nbFound += 1
       if nbDisp < maxDisp: 
          nbDisp += module_di.printBearerCtxByIndex(i)
  
  return nbDisp


def printCounters():
  """Prints counter values.
  Example:	printCounters()"""
  
  print '*** PGW counters ***'
  counters = module_di.getCounters()
  for key in sorted(set(counters)):
    print key, '=', counters[key]

  # add per QCI counters
  print '*** PGW per QCI counters ***'
  for i in range(1, 10):
    qcicounters = module_di.getQciCounters(i)
    for key in sorted(set(qcicounters)):
      print key, '[', i, ']', '=', qcicounters[key]
  

def prettyPrintCounters():
  """Prints counter values with more \"human readable\" information.
  Example:	prettyPrintCounters()"""
  
  counters = module_di.getCounters()
  
  print '*** PGW counters ***'
  # Number of attempts/successful bearer creations
  print 'Attempts default bearers = %u' % counters['globCreDefBAtt']
  print 'Successful default bearers = %u' %  counters['globCreDefBSucc']
  print 'Attempts dedicated bearers = %u' %  counters['globCreDedicBAtt']
  print 'Successful dedicated bearers = %u' %  counters['globCreDedicBSucc']
  # Number of T-PDU bytes sent in up/down direction
  print 'PDUs up (received on S5-U) = %u' %  counters['globUpPduRcv']
  print 'Bytes up (received on S5-U)= %u' %  counters['globUpBytesRcv']
  print 'PDUs up (sent on SGi) = %u' %  counters['globUpPduSend']
  print 'Bytes up (sent on SGi)= %u' %  counters['globUpBytesSend']
  print 'PDUs down (received on SGi) = %u' %  counters['globDownPduRcv']
  print 'Bytes down (received on SGi) = %u' %  counters['globDownBytesRcv']
  print 'PDUs down (sent on S5-U) = %u' %  counters['globDownPduSend']
  print 'Bytes down (sent on S5-U) = %u' %  counters['globDownBytesSend']
  # Signalling PDUs counters
#  print 'Sent Echo Rq = %u' %  counters['globDownEchoReq']
#  print 'Sent Echo Rsp = %u' %  counters['globDownEchoRsp']
  print 'Sent Error Ind = %u' %  counters['globDownErrorInd']
#  print 'Recv. Echo Rq = %u' %  counters['globUpEchoReq']
#  print 'Recv. Echo Rsp = %u' %  counters['globUpEchoRsp']
  print 'Recv. Error Ind = %u' %  counters['globUpErrorInd']
  print 'Recv. SupExtHead = %u' %  counters['globUpSuppExtHead']
  # Discarded PDUs counters
  print 'S5-U discarded sent signalling PDU = %u' %  counters['globDownSigDiscSendPb']
  print 'S5-U discarded sent data PDU = %u' %  counters['globDownDataS5uDiscSendPb']
  print 'S5-U discarded sent unknown pb = %u' %  counters['globDownDiscS5uUnknPb']
  print 'SGi discarded sent data PDU = %u' %  counters['globUpDataSGiDiscSendPb']
  print 'S5-U discarded recv. signalling PDU = %u' %  counters['globUpSigDiscFormatPb']
  print 'S5-U discarded recv. data PDU = %u' %  counters['globUpDataS5uDiscFormatPb']
  print 'S5-U discarded recv. unknown TEID PDU = %u' %  counters['globUpDataS5uDiscUnknownTeidPb']
  print 'S5-U discarded recv. unknown pb = %u' %  counters['globUpDiscS5uUnknPb']
  print 'SGi discarded recv. data PDU = %u' %  counters['globDownDataSGiDiscFormatPb']
  print 'SGi discarded recv. unknown IP address PDU = %u' %  counters['globDownDataSGiDiscUnknownIpPb']

  # Lost Number of T-PDU bytes sent in up/down direction
  print 'Lost PDUs up (while sending to SGi) = %u' %  counters['globNbUpLost']
  print 'Lost Bytes up (while sending to SGi)= %u' %  counters['globNbUpBytesLost']
  print 'Lost PDUs down (while sending to S5-U) = %u' %  counters['globNbDownLost']
  print 'Lost Bytes down (while sending to S5-U) = %u' %  counters['globNbDownBytesLost']


def printQciCounters(qci):
  """Print QCI counters by qci.
  Example:	printQciCounters(9)"""

  if qci < 10:
    print '*** PGW counters for QCI ',qci,' ***' 

    counters = module_di.getQciCounters(qci)
    for key in sorted(set(counters)):
      print key, '=', counters[key]

def printQciDlDropInfo(qci):
  """Print QCI Downlink drop info by qci.
  Example:	printQciDlDropInfo(9)"""

  if qci < 10:
    print module_di.getDlPduRecvQci(qci), ' ', module_di.getDlPduDropQci(qci)

def printGauges():
  """Prints gauge values.
  Example:	printGauges()"""
  
  print 'PGW Gauges:'

  gauges = module_di.getGauges()
  for key in sorted(set(gauges)):
    print '\t', key, '=', gauges[key]


def prettyPrintGauges():
  """Prints gauge values with more \"human readable\" information.
  Example:	prettyPrintGauges()"""
  
  gauges = module_di.getGauges()
  
  print '*** PGW gauges ***'
  print 'Attached SGWs = %u' % gauges['globAttSgw']
  print 'Attached UEs = %u' % gauges['globAttUEs']
  print 'Attached bearers = %u' %  gauges['globAttB']
  print 'Created default bearers = %u' %  gauges['globActDefB']
  print 'Created dedicated bearers = %u' %  gauges['globActDedicB']


def activity():
  
  activity = module_di.activity()
  
  print '%u ' % activity['globAttUEs']
  print '%u ' % activity['globAttB']
  print '%u ' % activity['globAttS']
  print '%u ' % activity['globDownBytesSend']
  print '%u ' % activity['globUpBytesRcv']
  print '%u ' % activity['globUpBytesSend']
  print '%u ' % activity['globDownBytesRcv']


def printConfiguration():
  """Display PGW configuration.
  Example:	printConfiguration()"""
  
  print 'PGW Configuration:'

  configuration = module_di.getConfiguration()
  for key in sorted(set(configuration)):
    print '\t', key, '=', configuration[key]


def prettyPrintConfiguration():
  """Prints configuration values with more \"human readable\" information.
  Example:	prettyPrintConfiguration()"""
  
  configuration = module_di.getConfiguration()
  
  for key in sorted(set(configuration)):
    print '\t', key, '=', configuration[key]
    

def printPcrfStatus():
  """Print current status of PCRF (0=bypass, 1=connected, 2=disconnected).
  Example:	printPcrfStatus()"""
  
  print "%d" % module_di.getPcrfStatus()

def printSgwStatus():
  """Print current number of known SGW (0=no SGW known).
  Example:	printSgwStatus()"""
  
  print "%d" % module_di.getSgwStatus()

def printTraceLevel():
  """Print current trace level for PGW module.
  Example:	printTraceLevel()"""
  
  print "Current trace levels:"
  print "PGW=0x%08x" % module_di.getTraceLevel()

def getNbAttUE():
  """Print number of attached UEs.
  Example:	getNbAttUE()"""
  
  print "Attached UEs=%d" % module_di.getNbAttUE()

def getNbAttBearer():
  """Print number of attached bearers.
  Example:	getNbAttBearer()"""
  
  print "Attached Bearers=%d" % module_di.getNbAttBearer()

def getNbAttSgw():
  """Print number of attached SGWs.
  Example:	getNbAttSgw()"""
  
  print "Attached SGW=%d" % module_di.getNbAttSgw()

def printUeCtxByIndex(i):
  """Print UE context by index.
  Example:	printUeCtxByIndex(1)"""
  
  result = 0

  try:
    module_di.printUeCtxByIndex(i)
    result += 1
  except ValueError:
    pass
  
  return result

def printBearerCtxByIndex(i):
  """Print Bearer context by index.
  Example:	printBearerCtxByIndex(1)"""
  
  result = 0

  try:
    module_di.printBearerCtxByIndex(i)
    result += 1
  except ValueError:
    pass
  
  return result

def printUeCtxByIMSI(imsi):
  """Print UE context by imsi.
  Example:	printUeCtxByIMSI(258516200001228)"""
  
  result = 0

  try:
    module_di.printUeCtxByIMSI(str(imsi))
    result += 1
  except ValueError:
    pass
  
  return result

def printUeCtxByRef(ref):
  """Print UE context by ref.
  Example:	printUeCtxByRef(1)"""
  
  result = 0

  try:
    module_di.printUeCtxByRef(ref)
    result += 1
  except ValueError:
    pass
  
  return result

def silentDeleteUeByRef(ref):
  """Delete UE context by ref without signaling.
  Example:	silentDeleteUeByRef(ref)"""
  
  result = 0

  try:
    module_di.silentDeleteUeByRef(ref)
    result += 1
  except ValueError:
    pass
  
  return result

def printBearerCtxByRef(ref):
  """Print Bearer context by ref.
  Example:	printBearerCtxByRef(ref)"""
  
  result = 0

  try:
    module_di.printBearerCtxByRef(ref)
    result += 1
  except ValueError:
    pass
  
  return result

def resetCounters():
  """Reset all counters.
  Example:	resetCounters()"""

  module_di.resetCounters()  

def printSgwCtxByIndex(i):
  """Print SGW context by index.
  Example:	printSgwCtxByIndex(1)"""
  
  result = 0

  try:
    module_di.printSgwCtxByIndex(i)
    result += 1
  except ValueError:
    pass
  
  return result

def printSgwCtxByRef(ref):
  """Print SGW context by ref.
  Example:	printSgwCtxByRef(ref)"""
  
  result = 0

  try:
    module_di.printSgwCtxByRef(ref)
    result += 1
  except ValueError:
    pass
  
  return result

def printSgwCtxList(maxDisp = module_di.getMaxSgw()):
  """Displays (up to given maximum number of contexts) list of
  allocated SGW contexts.
  Returns number of displayed items.
  Example:	printSgwCtxList()   # print list of all allocated SGW contexts
  Example:	printSgwCtxList(10) # print list of first 10 allocated SGW contexts"""
  
  maxSgw = module_di.getMaxSgw()
  nbDisp = 0
  nbFound = 0
  
  if maxDisp > maxSgw:
    maxDisp = maxSgw
  
  for i in range(1, maxSgw+1):
    if module_di.isSgwCtxUsed(i):
       nbFound += 1 
       if nbDisp < maxDisp: 
          nbDisp += module_di.printSgwCtxByIndex(i)
  
  return nbDisp

def printBearersByIMSI(imsi):
  """Print Bearer contexts by imsi.
  Example:	printBearersByIMSI(258516200001228)"""
  
  result = 0

  try:
    module_di.printBearersByIMSI(str(imsi))
    result += 1
  except ValueError:
    pass
  
  return result

def printGwVersion():
  """Print PGW module version.
  Example:	printGwVersion()"""
  
  print "gwversion=%s" % module_di.getGwVersion()

def printPfById(i):
  """Print PF content by id.
  Example:	printPfById(0)"""

  result = ''
  
  try:
    result += module_di.printPfById(i)
  except (ValueError, NameError, TypeError, RuntimeError, SyntaxError):
    sys.exc_clear()

  return result
  
def printRuleByName(name):
  """Print RULE content by name.
  Example:	printRuleByName(\"ping\")"""

  result = ''
  
  try:
    result += module_di.printRuleByName(name)
  except (ValueError, NameError, TypeError, RuntimeError, SyntaxError):
    sys.exc_clear()

  return result
  
def activateRuleForIMSI(imsi,name):
  """Activate RULE by name for a given IMSI.
  Example:	activateRuleForIMSI(\"310012000000001\",\"ping\")"""
  
  result = ''

  try:
    result += module_di.activateRuleForIMSI(imsi,name)
  except (ValueError, NameError, TypeError, RuntimeError, SyntaxError):
    sys.exc_clear()

  return result
  
def deactivateRuleForIMSI(imsi,name):
  """Deactivate RULE by name for a given IMSI.
  Example:	deactivateRuleForIMSI(\"310012000000001\",\"ping\")"""
  
  result = ''

  try:
    result += module_di.deactivateRuleForIMSI(imsi,name)
  except (ValueError, NameError, TypeError, RuntimeError, SyntaxError):
    sys.exc_clear()

  return result
  
def getRuleStatusForIMSI(imsi,name):
  """Query status of a RULE by name for a given IMSI.
  Example:	getRuleStatusForIMSI(\"310012000000001\",\"ping\")"""
  
  result = ''

  try:
    result += module_di.getRuleStatusForIMSI(imsi,name)
  except (ValueError, NameError, TypeError, RuntimeError, SyntaxError):
    sys.exc_clear()
  
  return result

def printPfList():
  """Print PF list.
  Example:	printPfList()"""

  result = ''
  
  try:
    result += module_di.printPfList()
  except (ValueError, NameError, TypeError, RuntimeError, SyntaxError):
    sys.exc_clear()

  return result
  
def printRuleList():
  """Print RULE list.
  Example:	printRuleList()"""

  result = ''
  
  try:
    result += module_di.printRuleList()
  except (ValueError, NameError, TypeError, RuntimeError, SyntaxError):
    sys.exc_clear()

  return result

def printLockDebug():
  """Print internal lock counters.
  Example:	printLockDebug()"""

  result = ''
  
  try:
    result += module_di.printLockDebug()
  except (ValueError, NameError, TypeError, RuntimeError, SyntaxError):
    sys.exc_clear()

  return result
  
