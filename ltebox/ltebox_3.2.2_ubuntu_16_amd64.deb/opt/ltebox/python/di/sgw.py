# "@(#) $SCMfile: gw.py@@/main/d_mme/9 2009/04/17 15:26:30 $"

"""DI functions for SGW module"""

import module_di

def printUeCtxList(maxDisp = module_di.getMaxUe()):
  """Displays (up to given maximum number of contexts) list of
  allocated UE contexts.
  Returns number of displayed items.
  Example:	printUeCtxList()   # print list of all allocated UE contexts
  Example:	printUeCtxList(30) # print list of first 30 allocated UE contexts"""
  
  maxUe = module_di.getMaxUe()
  nbDisp = 0
  nbFound = 0;
  
  if maxDisp > maxUe:
    maxDisp = maxUe
  
  for i in range(1, maxUe+1):
    if module_di.isUeCtxUsed(i):
       nbFound += 1
       if nbDisp < maxDisp: 
          nbDisp += module_di.printUeCtxByIndex(i)

  return nbDisp


def printBearerCtxList(maxDisp = module_di.getMaxUe() * (module_di.getMaxBearer()+1)):
  """Displays (up to given maximum number of contexts) list of
  allocated bearer contexts.
  Returns number of displayed items.
  Example:	printBearerCtxList()   # print list of all allocated bearer contexts
  Example:	printBearerCtxList(50) # print list of first 50 allocated bearer contexts"""
  
  maxBearer = module_di.getMaxUe() * (module_di.getMaxBearer()+1)
  nbDisp = 0
  nbFound = 0
  
  if maxDisp > maxBearer:
    maxDisp = maxBearer
  
  for i in range(1, maxBearer+1):
    if module_di.isBearerCtxUsed(i):
       nbFound += 1
       if nbDisp < maxDisp: 
          nbDisp += module_di.printBearerCtxByIndex(i)
  
  return nbDisp


def printEnbCtxList(maxDisp = module_di.getMaxEnb()):
  """Displays (up to given maximum number of contexts) list of
  allocated eNB contexts.
  Returns number of displayed items.
  Example:	printEnbCtxList()   # print list of all allocated eNB contexts
  Example:	printEnbCtxList(10) # print list of first 10 allocated eNB contexts"""
  
  maxEnb = module_di.getMaxEnb()
  nbDisp = 0
  nbFound = 0
  
  if maxDisp > maxEnb:
    maxDisp = maxEnb
  
  for i in range(1, maxEnb+1):
    if module_di.isEnbCtxUsed(i):
       nbFound += 1 
       if nbDisp < maxDisp: 
          nbDisp += module_di.printEnbCtxByIndex(i)
  
  return nbDisp


def printCounters():
  """Prints counter values.
  Example:	printCounters()"""
  
  print '*** SGW counters ***'
  counters = module_di.getCounters()
  for key in sorted(set(counters)):
    print key, '=', counters[key]

  # add per QCI counters
  print '*** SGW per QCI counters ***'
  for i in range(1, 10):
    qcicounters = module_di.getQciCounters(i)
    for key in sorted(set(qcicounters)):
      print key, '[', i, ']', '=', qcicounters[key]
  
def prettyPrintCounters():
  """Prints counter values with more \"human readable\" information.
  Example:	prettyPrintCounters()"""
  
  counters = module_di.getCounters()
  
  print '*** SGW counters ***'
  # Number of attempts/successful bearer creations
  print 'Attempts default bearers = %u' % counters['globCreDefBAtt']
  print 'Successful default bearers = %u' %  counters['globCreDefBSucc']
  print 'Attempts dedicated bearers = %u' %  counters['globCreDedicBAtt']
  print 'Successful dedicated bearers = %u' %  counters['globCreDedicBSucc']
  # Number of T-PDU bytes sent in up/down direction
  print 'PDUs up (received on S1-U) = %u' %  counters['globUpPduRcv']
  print 'Bytes up (received on S1-U)= %u' %  counters['globUpBytesRcv']
  print 'PDUs up (sent on S5-U) = %u' %  counters['globUpPduSend']
  print 'Bytes up (sent on S5-U)= %u' %  counters['globUpBytesSend']
  print 'PDUs down (received on S5-U) = %u' %  counters['globDownPduRcv']
  print 'Bytes down (received on S5-U) = %u' %  counters['globDownBytesRcv']
  print 'PDUs down (sent on S1-U) = %u' %  counters['globDownPduSend']
  print 'Bytes down (sent on S1-U) = %u' %  counters['globDownBytesSend']
  # Signalling PDUs counters
  print 'Sent Echo Rq = %u' %  counters['globDownEchoReq']
  print 'Sent Echo Rsp = %u' %  counters['globDownEchoRsp']
  print 'Sent Error Ind = %u' %  counters['globDownErrorInd']
  print 'Recv. Echo Rq = %u' %  counters['globUpEchoReq']
  print 'Recv. Echo Rsp = %u' %  counters['globUpEchoRsp']
  print 'Recv. Error Ind = %u' %  counters['globUpErrorInd']
  print 'Recv. SupExtHead = %u' %  counters['globUpSuppExtHead']
  # Discarded PDUs counters
  print 'S1-U discarded sent signalling PDU = %u' %  counters['globDownSigDiscSendPb']
  print 'S1-U discarded sent data PDU = %u' %  counters['globDownDataS1uDiscSendPb']
  print 'S1-U discarded sent unknown pb = %u' %  counters['globDownDiscS1uUnknPb']
  print 'S1-U discarded recv. signalling PDU = %u' %  counters['globUpSigDiscFormatPb']
  print 'S1-U discarded recv. data PDU = %u' %  counters['globUpDataS1uDiscFormatPb']
  print 'S1-U discarded recv. unknown TEID PDU = %u' %  counters['globUpDataS1uDiscUnknownTeidPb']
  print 'S1-U discarded recv. unknown pb = %u' %  counters['globUpDiscS1uUnknPb']

  # Lost Number of T-PDU bytes sent in up/down direction
  print 'Lost PDUs up (while sending to S5-U) = %u' %  counters['globNbUpLost']
  print 'Lost Bytes up (while sending to S5-U)= %u' %  counters['globNbUpBytesLost']
  print 'Lost PDUs down (while sending to S1-U) = %u' %  counters['globNbDownLost']
  print 'Lost Bytes down (while sending to S1-U) = %u' %  counters['globNbDownBytesLost']

def printQciCounters(qci):
  """Print QCI counters by qci.
  Example:	printQciCounters(9)"""

  if qci < 10:
    print '*** SGW counters for QCI ',qci,' ***' 

    counters = module_di.getQciCounters(qci)
    for key in sorted(set(counters)):
      print key, '=', counters[key]

def printGauges():
  """Prints gauge values.
  Example:	printGauges()"""
  
  print 'SGW Gauges:'

  gauges = module_di.getGauges()
  for key in sorted(set(gauges)):
    print '\t', key, '=', gauges[key]


def prettyPrintGauges():
  """Prints gauge values with more \"human readable\" information.
  Example:	prettyPrintGauges()"""
  
  gauges = module_di.getGauges()
  
  print '*** SGW gauges ***'
  print 'Attached UEs = %u' % gauges['globAttUEs']
  print 'Attached bearers = %u' %  gauges['globAttB']
  print 'Attached eNBs = %u' %  gauges['globAttEnb']
  print 'Attached PGWs = %u' %  gauges['globAttPgw']
  print 'Attached MMEs = %u' %  gauges['globAttMme']
  print 'Created default bearers = %u' %  gauges['globActDefB']
  print 'Created dedicated bearers = %u' %  gauges['globActDedicB']


def activity():
  
  activity = module_di.activity()
  
  print '%u ' % activity['globAttUEs']
  print '%u ' % activity['globAttEnb']
  print '%u ' % activity['globAttB']
  print '%u ' % activity['globAttP']
  print '%u ' % activity['globDownBytesSend']
  print '%u ' % activity['globUpBytesRcv']
  print '%u ' % activity['globUpBytesSend']
  print '%u ' % activity['globDownBytesRcv']


def printConfiguration():
  """Display SGW configuration.
  Example:	printConfiguration()"""
  
  print 'SGW Configuration:'

  configuration = module_di.getConfiguration()
  for key in sorted(set(configuration)):
    print '\t', key, '=', configuration[key]


def prettyPrintConfiguration():
  """Prints configuration values with more \"human readable\" information.
  Example:	prettyPrintConfiguration()"""
  
  configuration = module_di.getConfiguration()
  
  for key in sorted(set(configuration)):
    print '\t', key, '=', configuration[key]
    

def printMmeStatus():
  """Print current status of MME (0=unavailable, 1=available).
  Example:	printMmeStatus()"""
  
  print "%d" % module_di.getMmeStatus()

def printTraceLevel():
  """Print current trace level for SGW module.
  Example:	printTraceLevel()"""
  
  print "Current trace levels:"
  print "SGW=0x%08x" % module_di.getTraceLevel()

def getNbAttUE():
  """Print number of attached UEs.
  Example:	getNbAttUE()"""
  
  print "Attached UEs=%d" % module_di.getNbAttUE()

def getNbAttBearer():
  """Print number of attached bearers.
  Example:	getNbAttBearer()"""
  
  print "Attached Bearers=%d" % module_di.getNbAttBearer()

def getNbAttEnb():
  """Print number of attached eNodeBs.
  Example:	getNbAttEnb()"""
  
  print "Attached EnodeBs=%d" % module_di.getNbAttEnb()

def getNbAttPgw():
  """Print number of attached PGWs.
  Example:	getNbAttPgw()"""
  
  print "Attached PGWs=%d" % module_di.getNbAttPgw()

def getNbAttMme():
  """Print number of attached MMEs.
  Example:	getNbAttMme()"""
  
  print "Attached MMEs=%d" % module_di.getNbAttMme()

def printUeCtxByIndex(i):
  """Print UE context by index.
  Example:	printUeCtxByIndex(1)"""
  
  result = 0

  try:
    module_di.printUeCtxByIndex(i)
    result += 1
  except ValueError:
    pass
  
  return result

def printBearerCtxByIndex(i):
  """Print Bearer context by index.
  Example:	printBearerCtxByIndex(1)"""
  
  result = 0

  try:
    module_di.printBearerCtxByIndex(i)
    result += 1
  except ValueError:
    pass
  
  return result

def printEnbCtxByIndex(i):
  """Print ENodeB context by index.
  Example:	printEnbCtxByIndex(1)"""
  
  result = 0

  try:
    module_di.printEnbCtxByIndex(i)
    result += 1
  except ValueError:
    pass
  
  return result

def printUeCtxByIMSI(imsi):
  """Print UE context by imsi.
  Example:	printUeCtxByIMSI(258516200001228)"""
  
  result = 0

  try:
    module_di.printUeCtxByIMSI(str(imsi))
    result += 1
  except ValueError:
    pass
  
  return result

def printUeCtxByRef(ref):
  """Print UE context by ref.
  Example:	printUeCtxByRef(1)"""
  
  result = 0

  try:
    module_di.printUeCtxByRef(ref)
    result += 1
  except ValueError:
    pass
  
  return result

def silentDeleteUeByRef(ref):
  """Delete UE context by ref without signaling.
  Example:	silentDeleteUeByRef(ref)"""
  
  result = 0

  try:
    module_di.silentDeleteUeByRef(ref)
    result += 1
  except ValueError:
    pass
  
  return result

def printBearerCtxByRef(ref):
  """Print Bearer context by ref.
  Example:	printBearerCtxByRef(ref)"""
  
  result = 0

  try:
    module_di.printBearerCtxByRef(ref)
    result += 1
  except ValueError:
    pass
  
  return result

def printEnbCtxByRef(ref):
  """Print EnodeB context by ref.
  Example:	printEnbCtxByRef(ref)"""
  
  result = 0

  try:
    module_di.printEnbCtxByRef(ref)
    result += 1
  except ValueError:
    pass
  
  return result

def resetCounters():
  """Reset all counters.
  Example:	resetCounters()"""

  module_di.resetCounters()  

def printPgwStatus():
  """Print current number of PGW known by SGW (0=no PGW known).
  Example:	printPgwStatus()"""
  
  print "%d" % module_di.getPgwStatus()

def printPgwCtxByIndex(i):
  """Print PGW context by index.
  Example:	printPgwCtxByIndex(1)"""
  
  result = 0

  try:
    module_di.printPgwCtxByIndex(i)
    result += 1
  except ValueError:
    pass
  
  return result

def printPgwCtxByRef(ref):
  """Print PGW context by ref.
  Example:	printPgwCtxByRef(ref)"""
  
  result = 0

  try:
    module_di.printPgwCtxByRef(ref)
    result += 1
  except ValueError:
    pass
  
  return result

def printPgwCtxList(maxDisp = module_di.getMaxPgw()):
  """Displays (up to given maximum number of contexts) list of
  allocated PGW contexts.
  Returns number of displayed items.
  Example:	printPgwCtxList()   # print list of all allocated PGW contexts
  Example:	printPgwCtxList(10) # print list of first 10 allocated PGW contexts"""
  
  maxPgw = module_di.getMaxPgw()
  nbDisp = 0
  nbFound = 0
  
  if maxDisp > maxPgw:
    maxDisp = maxPgw
  
  for i in range(1, maxPgw+1):
    if module_di.isPgwCtxUsed(i):
       nbFound += 1 
       if nbDisp < maxDisp: 
          nbDisp += module_di.printPgwCtxByIndex(i)
  
  return nbDisp

def printMmeCtxByIndex(i):
  """Print MME context by index.
  Example:	printMmeCtxByIndex(1)"""
  
  result = 0

  try:
    module_di.printMmeCtxByIndex(i)
    result += 1
  except ValueError:
    pass
  
  return result

def printMmeCtxByRef(ref):
  """Print MME context by ref.
  Example:	printMmeCtxByRef(ref)"""
  
  result = 0

  try:
    module_di.printMmeCtxByRef(ref)
    result += 1
  except ValueError:
    pass
  
  return result

def printMmeCtxList(maxDisp = module_di.getMaxMme()):
  """Displays (up to given maximum number of contexts) list of
  allocated MME contexts.
  Returns number of displayed items.
  Example:	printMmeCtxList()   # print list of all allocated MME contexts
  Example:	printMmeCtxList(10) # print list of first 10 allocated MME contexts"""
  
  maxMme = module_di.getMaxMme()
  nbDisp = 0
  nbFound = 0
  
  if maxDisp > maxMme:
    maxDisp = maxMme
  
  for i in range(1, maxMme+1):
    if module_di.isMmeCtxUsed(i):
       nbFound += 1 
       if nbDisp < maxDisp: 
          nbDisp += module_di.printMmeCtxByIndex(i)
  
  return nbDisp

def printBearersByIMSI(imsi):
  """Print Bearer contexts by imsi.
  Example:	printBearersByIMSI(258516200001228)"""
  
  result = 0

  try:
    module_di.printBearersByIMSI(str(imsi))
    result += 1
  except ValueError:
    pass
  
  return result

def printGwVersion():
  """Print SGW module version.
  Example:	printGwVersion()"""
  
  print "gwversion=%s" % module_di.getGwVersion()


