
"""DI functions for MME module"""

import module_di

def printTraceLevels():
  """Print current list of trace module names along with trace levels set for them.
  Example:	printTraceLevels()"""
  
  print "Current trace levels:"
  moduleList = module_di.getTraceModuleNames()
  for module in sorted(set(moduleList)):
    print "%s=0x%08x" % (module, module_di.getTraceLevel(module)),


def __printUeCtx(ueCtx):
  """Displays given UE context."""
  
  result = "IMSI=%s" % ueCtx['imsi']
  result += ", ueRef=%s" % ueCtx['ue_ref']
  result += ", State=%s" % ueCtx['state']
  result += ", S1AP Ref=%s" % ueCtx['s1ap_ref']
  result += ", tai=%s" % ueCtx['tai']
  result += ", enbid=%s" % ueCtx['enb_id']
  result += ", cellid=%s" % ueCtx['cell_id']
  result += ", s1SubState=%s" % ueCtx['s1_substate']
  result += ", secSubState=%s" % ueCtx['sec_substate']
  result += ", drxParam=%u" % ueCtx['drx_param']
  result += ", nbiot=%u" % ueCtx['nbiot']
  result += ", psm=%u" % ueCtx['psm']
  result += ", BearerCount=%u" % len(ueCtx['bearers'])
  for bearerId, bearerCtx in ueCtx['bearers'].items():
    result += ", bCtx[%s]=%s" % (bearerId, bearerCtx['b_ref'])
  print result


def __printBearerCtx(bCtx):
  """Displays given bearer context."""
  
  result = "bRef=%s" % bCtx['b_ref']
  result += ", State=%s" % bCtx['state']
  result += ", default bearer id=%d" % bCtx['def_bearer_id']
  result += ", EPS Bearer Id=%u" % bCtx['epc_bearer_id']
  result += ", Session Ref=%s" % bCtx['session_ref']
  result += ", S1 Address U=%s" % bCtx['s1ap_address_u']
  result += ", S1 TEID U=0x%x" % bCtx['s1ap_teid_u']
  result += ", SGW Address U=%s" % bCtx['sgw_address_u']
  result += ", SGW TEID U=0x%x" % bCtx['sgw_teid_u']
  result += ", QoS label=%d" % bCtx['qos_label']
  result += ", QoS arp priority=%d" % bCtx['qos_arp_pri']
  result += ", QoS arp preempt-cap=%d" % bCtx['qos_arp_cap']
  result += ", QoS arp preempt-vul=%d" % bCtx['qos_arp_vul']
  result += ", QoS gbr type=%d" % bCtx['qos_gbr_type']
  if (bCtx['qos_gbr_type'] == 1):
    result += ", QoS ulmbr=%d" % bCtx['qos_gbr_ulmbr']
    result += ", QoS ulgbr=%d" % bCtx['qos_gbr_ulgbr']
    result += ", QoS dlmbr=%d" % bCtx['qos_gbr_dlmbr']
    result += ", QoS dlgbr=%d" % bCtx['qos_gbr_dlgbr']
  if (bCtx['qos_gbr_type'] == 0):
    result += ", QoS ulambr=%d" % bCtx['qos_ngbr_ulambr']
    result += ", QoS dlambr=%d" % bCtx['qos_ngbr_dlambr']

  print result


def printUeCtxByIndex(i):
  """Displays the context data for UE with given index.
  Returns number of printed items (i.e. 1 if ctx with given index
  does exist or 0 when ctx with given index is not allocated)."""
  
  result = 0
  
  try:
    ueCtx  = module_di.getUeCtxByIndex(i)
    print "UE Ctx[%u] INFO:" % i,
    __printUeCtx(ueCtx)
    result += 1
  except ValueError:
    pass
  
  return result


def printUeCtxByRef(ref):
  """Displays the context data for UE with given reference.
  Returns number of printed items (i.e. 1 if ctx with given reference
  does exist or 0 when ctx with given reference is not allocated)."""
  
  result = 0
  
  try:
    ueCtx  = module_di.getUeCtxByRef(ref)
    print "UE INFO:",
    __printUeCtx(ueCtx)
    result += 1
  except ValueError:
    pass
  
  return result


def printUeCtxByIMSI(imsi):
  """Displays the context data for UE with given IMSI.
  Returns number of printed items (i.e. 1 if ctx with given IMSI
  does exist or 0 when ctx with given reference is not allocated)."""
  
  result = 0
  
  try:
    ueCtx  = module_di.getUeCtxByIMSI(str(imsi))
    print "UE INFO:",
    __printUeCtx(ueCtx)
    result += 1
  except ValueError:
    pass
  
  return result


def getAllUeCtx():
  """Return all allocated UE contexts in dictionary with following structure:
  
    {
      <IMSI #1>: [ <list context items as returned by getMnCtxByRef()> ],
      # ...
    }
  """
  
  ctx_dict = {}
  for ue_index in range(0, module_di.getMaxUe()):
    try:
      ue_info = module_di.getUeCtxByIndex(ue_index)
      ctx_dict[ue_info['imsi']] = ue_info
    except ValueError:
      return ctx_dict
  
  return ctx_dict


def printUeCtxList(ctxCount = module_di.getMaxUe()):
  """Prints main parameters for several/all UE contexts (in: |count).
  Example:	printUeCtxList(10)"""
  
  maxUe = module_di.getMaxUe()
  if ctxCount > maxUe:
    ctxCount = maxUe

  for i in range(0, ctxCount):
    printUeCtxByIndex(i)


def printBCtxByRef(ref):
  """Displays the context data for bearer with given reference.
  Returns number of printed items (i.e. 1 if ctx with given reference
  does exist or 0 when ctx with given reference is not allocated)."""
  
  result = 0
  
  try:
    bCtx  = module_di.getBCtxByRef(ref)
    print "Bearer INFO:",
    __printBearerCtx(bCtx)
    result += 1
  except ValueError:
    pass
  
  return result


def printConfiguration():
  """Display MME configuration.
  Example:	printConfiguration()"""
  
  print '*** MME Configuration ***'

  configuration = module_di.getConfiguration()
  for key in sorted(set(configuration)):
    print key, '=', configuration[key]


def printCounters():
  """Display MME counters.
  Example:	printCounters()"""
  
  print '*** MME Counters ***'

  counters = module_di.getCounters()
  for key in sorted(set(counters)):
    print key, '=', counters[key]


def printGauges():
  """Display MME gauges.
  Example:	printGauges()"""
  
  print '*** MME Gauges ***'

  gauges = module_di.getGauges()
  for key in sorted(set(gauges)):
    print key, '=', gauges[key]

def getS6aStatus():
  """Display S6A connection status.
  Example:	getS6aStatus()"""
  
  print "%d" % module_di.getS6aStatus()

def detachAll():
  """Detach all UEs.
  Example:	detachAll()"""
  
  print 'Detaching all UEs'

  detach = module_di.detachAll()

def freeAllUeCtx():
  """Free all UEs.
  Example:	freeAllUeCtx()"""
  
  print 'Freeing all UEs'

  freeAllCtx = module_di.freeAllUeCtx()

#BMC has side effects (double free when mme stops !)
#def detachUeByIMSI(imsi):
#  """Detach UE with given IMSI.
#  Example:	detachUeByIMSI(imsi)"""
#  
#  module_di.detachUeByIMSI(str(imsi))

def detachAllFromENodeB(eNodeBid):
  """Detach all UEs of an eNodeB given the eNodeB ID.
  Example:	detachAllFromENodeB(50)"""
  
  detachUeByeNodeB  = module_di.detachAllFromENodeB(eNodeBid)

def __printMbmsCtx(mbmsCtx):
  """Displays given MBMS session context."""
  
  result = ", mbmsRef=%s" % mbmsCtx['ref']
  result += ", state=%s" % mbmsCtx['state']
  result += ", tmgi=%s" % mbmsCtx['tmgi']
  result += ", qos=%s" % mbmsCtx['qos']
  result += ", serviceArea=%s" % mbmsCtx['serviceArea']
  result += ", gtpTeid=%s" % mbmsCtx['gtpTeid']
  result += ", srcIp=%s" % mbmsCtx['srcIp']
  result += ", dtsIp=%s" % mbmsCtx['dstIp']
  print result

def printMbmsCtxByRef(ref):
  """Displays the context data for a MBMS session with given reference.
  Returns number of printed items (i.e. 1 if ctx with given reference
  does exist or 0 when ctx with given reference is not allocated)."""
  
  result = 0
  
  try:
    mbmsCtx  = module_di.getMbmsCtxByRef(ref)
    print "MBMS INFO:",
    __printMbmsCtx(mbmsCtx)
    result += 1
  except ValueError:
    pass
  
  return result

def printMbmsCtxByIndex(i):
  """Displays the context data for MBMS session with given index.
  Returns number of printed items (i.e. 1 if ctx with given index
  does exist or 0 when ctx with given index is not allocated)."""
  
  result = 0
  
  try:
    mbmsCtx  = module_di.getMbmsCtxByIndex(i)
    print "MBMS Ctx[%u] INFO:" % i,
    __printMbmsCtx(mbmsCtx)
    result += 1
  except ValueError:
    pass
  
  return result

def printMbmsCtxList(ctxCount = module_di.getMaxMbms()):
  """Prints main parameters for several/all MBMS session contexts (in: |count).
  Example:	printMbmsCtxList(10)"""
  
  maxMbms = module_di.getMaxMbms()
  if ctxCount > maxMbms:
    ctxCount = maxMbms

  print "*** MBMS sessions ***"

  for i in range(0, ctxCount):
    act = module_di.isMbmsIndexActive(i)
    if (act == 1):
      printMbmsCtxByIndex(i)

def sendMmeOverloadStart(i = 0):
  """Send MME overload start to all active eNB's with specified action as input argument:
  0=reject non-emergency mobile services (default); 1=reject all; 2=permit emergency only."""
  
  result = 0
  
  try:
    module_di.sendMmeOverloadStart(i)
  except ValueError:
    pass

  return result
  
def sendMmeOverloadStop():
  """Send MME overload stop to all active eNB's."""
  
  result = 0
  
  try:
    module_di.sendMmeOverloadStop()
  except ValueError:
    pass

  return result
  








