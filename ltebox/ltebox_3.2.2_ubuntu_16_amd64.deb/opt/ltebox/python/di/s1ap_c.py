# "@(#) $MMEfile: s1ap_c.py@@/main/d_mme/3 2008/08/18 14:45:24 $"

"""DI functions for MME S1AP-C module"""

import module_di

def getCompilationInfo():
  """Print compilation info
  Example:	getCompilationInfo()"""
  
  cinfo = module_di.getCompilationInfo()
  print cinfo

def printENBs():
  """Print ENBs info
  Example:	printENBs()"""
  
  module_di.printENBs()

def printSCTPSockets():
  """Print SCTP sockets info
  Example:	printSCTPSockets()"""
  
  module_di.printSCTPSockets()

def printTAs():
  """Print Tracking Area info
  Example:	printTAs()"""
  
  module_di.printTAs()

def closeSCTPSocket(sid):
  """Close SCTP socket identified by id
  Example:	closeSCTPSocket(0)"""
  
  module_di.closeSCTPSocket(sid)

def getS1apEnbCount():
  """Print number of S1AP connected eNB's
  Example:	getS1apEnbCount()"""
  
  enbcount = module_di.getS1apEnbCount()
  print enbcount

