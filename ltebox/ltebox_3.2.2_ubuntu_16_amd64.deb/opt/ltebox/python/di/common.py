# "@(#) $SCMfile: common.py@@/main/d_mme/2 2009/08/24 13:13:32 $"

"""Addtional DI functions common for all MME modules.

Following functions provide extended functionality ontop of core
debug functions in "common_di" Python module which is implemented
by MME Debug Interface library in C."""

import calendar
import time

import common_di

def printLog4cCategoryList():
  """Print current list of categories along with priorities set for them.
  Example:	printLog4cCategoryList()"""
  
  print "Prio.\tCategory"
  categoryList = common_di.log4cCategoryList()
  for category in sorted(set(categoryList)):
    print "%d\t%s" % (common_di.log4cGetCategoryPriority(category), category)


startup_timestamp = calendar.timegm(time.gmtime())

def get_startup_timestamp():
  """Returns timestamp representing time when the ePC module using
  MME DI library started (more precisely, timestamp of the moment,
  when this module has been interpreted).
  
  Can be used to detect unexpected module restarts by the users
  of the DI."""
  
  return startup_timestamp
