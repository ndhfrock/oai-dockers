#!/bin/sh
tempfile=`mktemp -p /tmp`
echo "setTraceLevel($1)" > $tempfile
/opt/ltebox/bin/mme_di_client -m pgw -b < $tempfile
rm -f $tempfile 
