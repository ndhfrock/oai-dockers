#!/bin/bash
#
# Nokia 2017
#
# olivier.marce@nokia-bell-labs.com
# bruno.mongazon-cazavet@nokia-bell-labs.com
#
# states:
#
# 0 = no bearer
# 1 = one or more bearers
# 2 = no more bearers
#
# input arguments:
#
# $1 eNB IP address to monitor
# $2 number of cycles of 5 seconds to run in powersave mode before powering off eNB
#
state=0
cycle=5
nbcycle=0
maxcycle=$2
enbip=$1
#
if [ "$#" -ne 2 ]
then
  echo "Usage: $0 eNB_IP_address cycles" >&2
  exit 1
fi
#
#
echo "Monitoring eNB $enbip with 5s cycles"
echo "Will poweroff eNB after $maxcycle cycles since last disconnection"
while [ 1 ]
do
    tempfile=`mktemp -p /tmp`
    /opt/ltebox/bin/mme_di_client -m mash -b < /opt/ltebox/tools/gauges_mme > $tempfile
    bearers=`grep "nbActiveDefaultBearers" $tempfile | cut -f3 -d" "`
    echo "Number of active connections is $bearers on eNB $enbip"
    if [ $state -eq 0 ]
    then
       if [ $bearers -gt 0 ]
       then
	  state=1
	  echo "New connection detected on eNB $enbip"
       fi
    else
	if [ $state -eq 1 ]
	then
	   if [ $bearers -eq 0 ]
	   then
	       echo "No more active connection on eNB $enbip, entering powersave mode"
	       state=2
	       nbcycle=0
	   fi
	else
	    if [ $state -eq 2 ]
	    then
	        echo "Powersave mode cycles=$nbcycle/$maxcycle on eNB $enbip"
		if [ $bearers -eq 0 ]
		then
		    if [ $nbcycle -eq $maxcycle ]
		    then
			echo "Powering off eNB $enbip"
			ssh -o StrictHostKeyChecking=no -i lci4d root@$enbip poweroff
			state=0
		    fi
		else
		    state=1
		fi
	    fi
	fi
    fi
    \rm -f $tempfile
    sleep 5
    let "nbcycle++"
done
\rm -f $tempfile
