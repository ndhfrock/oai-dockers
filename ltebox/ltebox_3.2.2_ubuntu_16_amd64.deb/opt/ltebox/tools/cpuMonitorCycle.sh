#!/bin/sh
#-------------------------------------------------------------------------------
#				********	cpuMonitorCycle	********
#
#   Copyright (c) 2014 Alcatel-Lucent
#
#   This file is part of the 9773 LMC project.
# 
#   To report bugs, send an e-mail to lmc-tier4@alcatel-lucent.com
#
#   Author   : Amine EL MLAHEG
#   Version  : 1.1
#   OS: RHEL6 x86_64
#   Release Date : Fri Nov 13 2014
#-------------------------------------------------------------------------------

# get application argument (sgw or pgw)
appli=$1
gsem_host="10.99.1.200"
declare -i cpuLimit=98
#declare -i cpuLimit=-1


# Main Program
if [[ ! -z $appli ]]
then
{
  # Check argument
  if [[ $appli = "sgw" ]]
  then
  {
     agentFileToCheck="/opt/agent_sGW/"
     neId="SGW-OAM"
  }
  else
  {
    if [[ $appli = "pgw" ]]
    then
    {
     agentFileToCheck="/opt/agent_pGW/"
     neId="PGW-OAM"
    }
    else
    {
     echo "usage: cpuMonitorCycle <application name> where <application name> is sgw or pgw"
     exit
    }
    fi
  }
  fi
  
 # Check application CPU
 cpu=`ps -C $appli -o pcpu |grep -v CPU | awk -F . '{print $1}'`
 cpuone=`echo $cpu | cut -d' ' -f1`
# echo $cpuone
 if [[ $cpuone -gt $cpuLimit ]]
 then
 {
  logger "** $appli CPU Warning **: The $appli process CPU usage is larger than $cpuLimit%"
  diclientStatus=`activity_$appli.sh`
  if [[ -z $diclientStatus ]]
  then
  {
    diclientStatus2ndAttempt=`activity_$appli.sh`
    if [[ -z $diclientStatus2ndAttempt ]]
    then
    {
      #get the Application PID
       pid=`pgrep -x $appli`
       
       #Kill the Application Process
       pkill -11 $appli
       logger "** $appli CPU ALERT **: The $appli PID is blocked, $appli process ($pid) killed for defense reason"
       sleep 1
       
       #Check if old Logs files exist and delete it
       if [[ -f /opt/ltebox/var/log/cpucrashlog-$appli.tar.gz ]]
       then
       {
         rm -rf /opt/ltebox/var/log/cpucrashlog-$appli.tar.gz
       }
       fi
       #Create an archive for the new coreDump and logs
       cp -f /var/log/messages /opt/ltebox/var/log/
       tar czf /tmp/cpucrashlog-$appli.tar.gz /opt/ltebox/var/log 2>&1 | grep -v "Removing leading"
       mv /tmp/cpucrashlog-$appli.tar.gz /opt/ltebox/var/log
       logger "** $appli CPU ALERT **: cpucrashlog-$appli.tar.gz created in /opt/ltebox/var/log."
       
       #Delete coreDump File to Save Memory
       rm -rf /opt/ltebox/var/log/core.$appli
       
       #Check if snmp agent is installed and send trap to GSEM Sever
       if [[ -d $agentFileToCheck ]]
       then
       {
        logger "** $appli CPU ALERT **: Trap sent to GSEM Server."
        snmptrap -v 2c -c public $gsem_host 0 1.3.6.1.4.1.2021.13  1.3.6.1.4.1.2021.13 s "The $appli process ($pid) was restarted by AppMgr due to abnormal CPU Usage (This is an informative alarm and need to be cleared manually)" sysName.0 s $neId
       }
       else
       {
        logger "** $appli CPU Warning **: Cannot send Trap to GSEM Server as the SNMP Agent is not installed."
       }
       fi
    }
    fi
  }
  else
  {
   logger "** $appli CPU Warning **: Normal Behaviour, The $appli PID still alive"
  }
  fi
 }
 fi
}
else
{
 echo "usage: cpuMonitorCycle <application name> where <application name> is sgw or pgw"
}
fi