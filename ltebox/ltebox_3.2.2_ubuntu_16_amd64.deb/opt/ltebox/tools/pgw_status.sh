#!/bin/sh
/opt/ltebox/bin/mme_di_client -m sgw -b < /opt/ltebox/tools/pgw_status
