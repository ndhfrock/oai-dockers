#!/bin/bash
#
# Nokia 2017
#
# Credits:
# -olivier.marce@nokia.com
# -bruno.mongazon-cazavet@nokia.com
# -francois.fornier@nokia.com
#
# Use temporary file
#
tempfile=`mktemp -p /tmp`
resfilea=`mktemp -p /tmp`
resfileb=`mktemp -p /tmp`
a=0
b=0
declare -a taba
declare -a tabb
declare -A before
declare -A after
#
# Print bearers stats by one second into files
#
echo "printBearersByIMSI(\"$1\")" > $tempfile
/opt/ltebox/bin/mme_di_client -m pgw -b < $tempfile > $resfileb
sleep 1
/opt/ltebox/bin/mme_di_client -m pgw -b < $tempfile > $resfilea
#
# Map result files into arrays
#
mapfile -t tabb < $resfileb
mapfile -t taba < $resfilea
c=0
utotal=0
ubtotal=0
ugtotal=0
dtotal=0
dbtotal=0
dgtotal=0
if [ ${#taba[@]} -eq ${#tabb[@]} ]
then
clear
date
echo -e "                                          \033[31mUplink         \033[32mDownlink\033[0m"
#\n                                     \033[34m...\033[36m...\033[33m...\033[35m...\033[0m      \033[34m...\033[36m...\033[33m...\033[35m...\033[0m"
while [ $c -lt ${#taba[@]} ]
do
    eval `echo ${tabb[$c]} | sed 's/\([^=]*\)=\([^ ]*\)[ ]*/before["\1"]=\2;/g'`
    eval `echo ${taba[$c]} | sed 's/\([^=]*\)=\([^ ]*\)[ ]*/after["\1"]=\2;/g'`
    # compute bit rates in bps
    urate=`expr ${after["U"]} - ${before["U"]}`
    drate=`expr ${after["D"]} - ${before["D"]}`
    urate=`expr $urate \* 8`
    drate=`expr $drate \* 8`
    utotal=`expr $utotal + $urate`
    dtotal=`expr $dtotal + $drate`
    if [[ ${after["Q"]} == "01"* ]] || [[ ${before["Q"]} == "02"* ]] || [[ ${before["Q"]} == "03"* ]] || [[ ${before["Q"]} == "04"* ]]; then
	gbr=1
	ugtotal=`expr $ugtotal + $urate`
	dgtotal=`expr $dgtotal + $drate`
    else
	gbr=0
	ubtotal=`expr $ubtotal + $urate`
	dbtotal=`expr $dbtotal + $drate`
    fi
    newline=${taba[$c]}" "$urate" bps"" "$drate" bps"
    if [ $gbr == 0 ]; then
	echo -e $newline | awk '{ printf("%-17s %s \033[36m%s \033[31m%11d\033[0m %s  \033[32m%11d\033[0m %s\n", $1, $3, $4, $11, $12, $13, $14); }'
    else
	echo -e $newline | awk '{ printf("%-17s %s \033[35m%s \033[31m%11d\033[0m %s  \033[32m%11d\033[0m %s\n", $1, $3, $4, $11, $12, $13, $14); }'
    fi
    let "c++"
done
totalgline="$ugtotal"" ""bps"" "$dgtotal" bps"
totalbline="$ubtotal"" ""bps"" "$dbtotal" bps"
totalline="$utotal"" ""bps"" "$dtotal" bps"
#echo -e "                                     \033[34m...\033[36m...\033[33m...\033[35m...\033[0m      \033[34m...\033[36m...\033[33m...\033[35m...\033[0m"
echo -e $totalgline | awk '{ printf("\n                     \033[35mTotal  GBR_rate \033[31m%11d\033[0m %s  \033[32m%11d\033[0m %s\n", $1, $2, $3, $4); }'
echo -e $totalbline | awk '{ printf("                     \033[36mTotal NGBR_rate \033[31m%11d\033[0m %s  \033[32m%11d\033[0m %s\n", $1, $2, $3, $4); }'
echo -e $totalline  | awk '{ printf("                     Total           \033[31m%11d\033[0m %s  \033[32m%11d\033[0m %s\n", $1, $2, $3, $4); }'

fi
\rm -f $resfilea
\rm -f $resfileb
\rm -f $tempfile

