#!/bin/sh
tempfile=`mktemp -p /tmp`
echo "setTraceLevel($1)" > $tempfile
/opt/ltebox/bin/mme_di_client -m gw -b < $tempfile
rm -f $tempfile 
