#!/bin/sh
/opt/ltebox/bin/mme_di_client -m gw -b < /opt/ltebox/tools/contexts
