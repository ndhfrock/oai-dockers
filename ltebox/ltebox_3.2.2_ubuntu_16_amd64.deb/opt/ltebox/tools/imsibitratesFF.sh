#!/bin/bash
#
# Nokia 2016
#
# Credits:
# -olivier.marce@nokia-bell-labs.com
# -bruno.mongazon-cazavet@nokia-bell-labs.com
# -francois.fornier@nokia.com
#
# Use temporary file
#
tempfile=`mktemp -p /tmp`
resfilea=`mktemp -p /tmp`
resfileb=`mktemp -p /tmp`
resfilec=`mktemp -p /tmp`
a=0
b=0
declare -a taba
declare -a tabb
declare -A before
declare -A after
bold=$(tput bold)
normal=$(tput sgr0)
#
# Print bearers stats by one second into files
#
echo "printBearersByIMSI(\"$1\")" > $tempfile
/opt/ltebox/bin/mme_di_client -m gw -b < $tempfile | sort > $resfileb
sleep 1
/opt/ltebox/bin/mme_di_client -m gw -b < $tempfile | sort > $resfilea
#
# Map result files into arrays
#
mapfile -t tabb < $resfileb
mapfile -t taba < $resfilea
c=0
utotal=0
ubtotal=0
ugtotal=0
dtotal=0
dbtotal=0
dgtotal=0
if [ ${#taba[@]} -eq ${#tabb[@]} ]
then
clear
date
echo -e "                                            \033[31mUplink         \033[32mDownlink\033[0m"
#\n                                     \033[34m...\033[36m...\033[33m...\033[35m...\033[0m      \033[34m...\033[36m...\033[33m...\033[35m...\033[0m"
while [ $c -lt ${#taba[@]} ]
do
    eval `echo ${tabb[$c]} | sed 's/\([^=]*\)=\([^ ]*\)[ ]*/before["\1"]=\2;/g'`
    eval `echo ${taba[$c]} | sed 's/\([^=]*\)=\([^ ]*\)[ ]*/after["\1"]=\2;/g'`
    # compute bit rates in bps
    urate=`expr ${after["U"]} - ${before["U"]}`
    drate=`expr ${after["D"]} - ${before["D"]}`
    urate=`expr $urate \* 8`
    drate=`expr $drate \* 8`
    utotal=`expr $utotal + $urate`
    dtotal=`expr $dtotal + $drate`
    if [[ ${after["Q"]} == "01"* ]] || [[ ${before["Q"]} == "02"* ]] || [[ ${before["Q"]} == "03"* ]] || [[ ${before["Q"]} == "04"* ]]; then
	gbr=1
	ugtotal=`expr $ugtotal + $urate`
	dgtotal=`expr $dgtotal + $drate`
    else
	gbr=0
	ubtotal=`expr $ubtotal + $urate`
	dbtotal=`expr $dbtotal + $drate`
    fi

    #
    # Ajout de l'IP du SG
    #
    bearerRef=`echo ${taba[$c]} | sed -e 's/^.*=//' | head -1`
    echo "printBearerCtxByRef($bearerRef)" > $tempfile
    /opt/ltebox/bin/mme_di_client -m gw -b < $tempfile > $resfilec
    s1_U_eNBRef=`grep "S1-U eNB ref=" $resfilec | sed -e 's/^.*=//' | head -1`
    echo "printEnbCtxByRef($s1_U_eNBRef)" > $tempfile
    /opt/ltebox/bin/mme_di_client -m gw -b < $tempfile > $resfilec
    eNBIPaddr=`grep "eNB IP addr=" $resfilec | sed -e 's/^.*=//'| head -1 `
    foo="`echo ${taba[$c]}  | sed -e 's/ [^ ]*$//'`"

    if grep -Fxq $eNBIPaddr /opt/ltebox/etc/gnb.conf; then
        newline=$foo" "$urate" bps"" "$drate" bps \033[32m"$bold$eNBIPaddr" \033[36m5GNR\033[0m"$standard
    else
        newline=$foo" "$urate" bps"" "$drate" bps \033[31m"$bold$eNBIPaddr" \033[35m4G\033[0m"$tandard
    fi

    if [ $gbr == 0 ]; then
	echo -e $newline | awk '{ printf("%-17s %s \033[36m%s  \033[31m%\04711d\033[0m %s  \033[32m%\04711d\033[0m %s GTP-IP=%-15s %s\n", $1, $3, $4, $11, $12, $13, $14, $15, $16); }'
    else
	echo -e $newline | awk '{ printf("%-17s %s \033[35m%s  \033[31m%\04711d\033[0m %s  \033[32m%\04711d\033[0m %s GTP-IP=%-15s %s\n", $1, $3, $4, $11, $12, $13, $14, $15, $16); }'
    fi
    let "c++"
done
totalgline="$ugtotal"" ""bps"" "$dgtotal" bps"
totalbline="$ubtotal"" ""bps"" "$dbtotal" bps"
totalline="$utotal"" ""bps"" "$dtotal" bps"
#echo -e "                                     \033[34m...\033[36m...\033[33m...\033[35m...\033[0m      \033[34m...\033[36m...\033[33m...\033[35m...\033[0m"
echo -e $totalgline | awk '{ printf("\n                     \033[35mTotal  GBR_rate  \033[31m%\04711d\033[0m %s  \033[32m%\04711d\033[0m %s\n", $1, $2, $3, $4); }'
echo -e $totalbline | awk '{ printf("                     \033[36mTotal NGBR_rate  \033[31m%\04711d\033[0m %s  \033[32m%\04711d\033[0m %s\n", $1, $2, $3, $4); }'
echo -e $totalline  | awk '{ printf("                     Total            \033[31m%\04711d\033[0m %s  \033[32m%\04711d\033[0m %s\n", $1, $2, $3, $4); }'

fi
\rm -f $resfilea
\rm -f $resfileb
\rm -f $resfilec
\rm -f $tempfile

