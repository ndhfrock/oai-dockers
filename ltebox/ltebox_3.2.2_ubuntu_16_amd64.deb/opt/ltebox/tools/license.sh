#!/bin/sh
export LD_LIBRARY_PATH=/opt/ltebox/lib
/opt/ltebox/bin/checklicense
