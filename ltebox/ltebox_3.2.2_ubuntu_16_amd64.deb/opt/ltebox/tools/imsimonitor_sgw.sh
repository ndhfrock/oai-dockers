#!/bin/sh
tempfile=`mktemp -p /tmp`
echo "printBearersByIMSI(\"$1\")" > $tempfile
/opt/ltebox/bin/mme_di_client -m sgw -b < $tempfile
rm -f $tempfile 

