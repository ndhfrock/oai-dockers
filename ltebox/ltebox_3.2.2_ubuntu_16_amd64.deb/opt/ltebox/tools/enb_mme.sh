#!/bin/sh
/opt/ltebox/bin/mme_di_client -m s1ap_c -b < /opt/ltebox/tools/enb_s1ap
