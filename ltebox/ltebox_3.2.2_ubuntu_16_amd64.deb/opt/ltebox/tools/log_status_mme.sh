#!/bin/sh

ret=$(grep -w FATAL /opt/ltebox/var/log/mmeLog.0)
if [ "$ret" ] ; then
    echo "2" ; exit 0
fi
ret=$(grep -w FATAL /opt/ltebox/var/log/s11cLog.0)
if [ "$ret" ] ; then
    echo "2" ; exit 0
fi
ret=$(grep -w FATAL /opt/ltebox/var/log/smcLog.0)
if [ "$ret" ] ; then
    echo "2" ; exit 0
fi
ret=$(grep -w FATAL /opt/ltebox/var/log/s1apcLog.0)
if [ "$ret" ] ; then
    echo "2" ; exit 0
fi
ret=$(grep -w FATAL /opt/ltebox/var/log/s1apcAsn1cLog.0)
if [ "$ret" ] ; then
    echo "2" ; exit 0
fi
ret=$(grep -w FATAL /opt/ltebox/var/log/s1apsLog.0)
if [ "$ret" ] ; then
    echo "2" ; exit 0
fi
ret=$(grep -w FATAL /opt/ltebox/var/log/s1apsAsn1cLog.0)
if [ "$ret" ] ; then
    echo "2" ; exit 0
fi
ret=$(grep -w FATAL /opt/ltebox/var/log/s1apDumpLog.0)
if [ "$ret" ] ; then
    echo "2" ; exit 0
fi
ret=$(grep -w FATAL /opt/ltebox/var/log/m3apcLog.0)
if [ "$ret" ] ; then
    echo "2" ; exit 0
fi
ret=$(grep -w FATAL /opt/ltebox/var/log/m3apsLog.0)
if [ "$ret" ] ; then
    echo "2" ; exit 0
fi
ret=$(grep -w ERR /opt/ltebox/var/log/mmeLog.0)
if [ "$ret" ] ; then
    echo "2" ; exit 0
fi
ret=$(grep -w ERR /opt/ltebox/var/log/s11cLog.0)
if [ "$ret" ] ; then
    echo "2" ; exit 0
fi
ret=$(grep -w ERR /opt/ltebox/var/log/smcLog.0)
if [ "$ret" ] ; then
    echo "2" ; exit 0
fi
ret=$(grep -w ERR /opt/ltebox/var/log/s1apcLog.0)
if [ "$ret" ] ; then
    echo "2" ; exit 0
fi
ret=$(grep -w ERR /opt/ltebox/var/log/s1apcAsn1cLog.0)
if [ "$ret" ] ; then
    echo "2" ; exit 0
fi
ret=$(grep -w ERR /opt/ltebox/var/log/s1apsLog.0)
if [ "$ret" ] ; then
    echo "2" ; exit 0
fi
ret=$(grep -w ERR /opt/ltebox/var/log/s1apsAsn1cLog.0)
if [ "$ret" ] ; then
    echo "2" ; exit 0
fi
ret=$(grep -w ERR /opt/ltebox/var/log/s1apDumpLog.0)
if [ "$ret" ] ; then
    echo "2" ; exit 0
fi
ret=$(grep -w ERR /opt/ltebox/var/log/m3apcLog.0)
if [ "$ret" ] ; then
    echo "2" ; exit 0
fi
ret=$(grep -w ERR /opt/ltebox/var/log/m3apsLog.0)
if [ "$ret" ] ; then
    echo "2" ; exit 0
fi
ret=$(grep -w ERROR /opt/ltebox/var/log/mmeLog.0)
if [ "$ret" ] ; then
    echo "2" ; exit 0
fi
ret=$(grep -w ERROR /opt/ltebox/var/log/s11cLog.0)
if [ "$ret" ] ; then
    echo "2" ; exit 0
fi
ret=$(grep -w ERROR /opt/ltebox/var/log/smcLog.0)
if [ "$ret" ] ; then
    echo "2" ; exit 0
fi
ret=$(grep -w ERROR /opt/ltebox/var/log/s1apcLog.0)
if [ "$ret" ] ; then
    echo "2" ; exit 0
fi
ret=$(grep -w ERROR /opt/ltebox/var/log/s1apcAsn1cLog.0)
if [ "$ret" ] ; then
    echo "2" ; exit 0
fi
ret=$(grep -w ERROR /opt/ltebox/var/log/s1apsLog.0)
if [ "$ret" ] ; then
    echo "2" ; exit 0
fi
ret=$(grep -w ERROR /opt/ltebox/var/log/s1apsAsn1cLog.0)
if [ "$ret" ] ; then
    echo "2" ; exit 0
fi
ret=$(grep -w ERROR /opt/ltebox/var/log/s1apDumpLog.0)
if [ "$ret" ] ; then
    echo "2" ; exit 0
fi
ret=$(grep -w ERROR /opt/ltebox/var/log/m3apcLog.0)
if [ "$ret" ] ; then
    echo "2" ; exit 0
fi
ret=$(grep -w ERROR /opt/ltebox/var/log/m3apsLog.0)
if [ "$ret" ] ; then
    echo "2" ; exit 0
fi
ret=$(grep -w WARN /opt/ltebox/var/log/mmeLog.0)
if [ "$ret" ] ; then
    echo "1" ; exit 0
fi
ret=$(grep -w WARN /opt/ltebox/var/log/s11cLog.0)
if [ "$ret" ] ; then
    echo "1" ; exit 0
fi
ret=$(grep -w WARN /opt/ltebox/var/log/smcLog.0)
if [ "$ret" ] ; then
    echo "1" ; exit 0
fi
ret=$(grep -w WARN /opt/ltebox/var/log/s1apcLog.0)
if [ "$ret" ] ; then
    echo "1" ; exit 0
fi
ret=$(grep -w WARN /opt/ltebox/var/log/s1apcAsn1cLog.0)
if [ "$ret" ] ; then
    echo "1" ; exit 0
fi
ret=$(grep -w WARN /opt/ltebox/var/log/s1apsLog.0)
if [ "$ret" ] ; then
    echo "1" ; exit 0
fi
ret=$(grep -w WARN /opt/ltebox/var/log/s1apsAsn1cLog.0)
if [ "$ret" ] ; then
    echo "1" ; exit 0
fi
ret=$(grep -w WARN /opt/ltebox/var/log/s1apDumpLog.0)
if [ "$ret" ] ; then
    echo "1" ; exit 0
fi
ret=$(grep -w WARN /opt/ltebox/var/log/m3apcLog.0)
if [ "$ret" ] ; then
    echo "1" ; exit 0
fi
ret=$(grep -w WARN /opt/ltebox/var/log/m3apsLog.0)
if [ "$ret" ] ; then
    echo "1" ; exit 0
fi
echo "0" ; exit 0


