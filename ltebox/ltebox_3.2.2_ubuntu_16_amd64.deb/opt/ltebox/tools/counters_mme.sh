#!/bin/sh
/opt/ltebox/bin/mme_di_client -m mash -b < /opt/ltebox/tools/counters_mme
