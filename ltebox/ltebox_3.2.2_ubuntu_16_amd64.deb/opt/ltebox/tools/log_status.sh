#!/bin/sh

ret=$(grep -w FATAL -s /opt/ltebox/var/log/xGwLog.0)
if [ "$ret" ] ; then
    echo "2" ; exit 0
fi
ret=$(grep -w FATAL -s /opt/ltebox/var/log/libLog.0)
if [ "$ret" ] ; then
    echo "2" ; exit 0
fi
ret=$(grep -w ERR -s /opt/ltebox/var/log/xGwLog.0)
if [ "$ret" ] ; then
    echo "2" ; exit 0
fi
ret=$(grep -w ERR -s /opt/ltebox/var/log/libLog.0)
if [ "$ret" ] ; then
    echo "2" ; exit 0
fi
ret=$(grep -w WARN -s /opt/ltebox/var/log/xGwLog.0)
if [ "$ret" ]; then
    echo "1" ; exit 0
fi
ret=$(grep -w WARN -s /opt/ltebox/var/log/libLog.0)
if [ "$ret" ]; then
    echo "1" ; exit 0
fi
echo "0" ; exit 0


