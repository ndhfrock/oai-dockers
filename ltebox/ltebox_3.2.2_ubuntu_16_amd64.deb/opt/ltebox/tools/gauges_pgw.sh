#!/bin/sh
/opt/ltebox/bin/mme_di_client -m pgw -b < /opt/ltebox/tools/gauges
