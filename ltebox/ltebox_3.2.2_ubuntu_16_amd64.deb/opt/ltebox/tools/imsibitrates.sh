#!/bin/bash
#
# Nokia 2016
#
# Credits:
# -olivier.marce@nokia-bell-labs.com
# -bruno.mongazon-cazavet@nokia-bell-labs.com
# -francois.fornier@nokia.com
#
# Use temporary file
#
tempfile=`mktemp -p /tmp`
resfilea=`mktemp -p /tmp`
resfileb=`mktemp -p /tmp`
resfilec=`mktemp -p /tmp`
a=0
b=0
declare -a taba
declare -a tabb
declare -A before
declare -A after
#
# Print bearers stats by one second into files
#
echo "printBearersByIMSI(\"$1\")" > $tempfile
/opt/ltebox/bin/mme_di_client -m gw -b < $tempfile > $resfileb
sleep 1
/opt/ltebox/bin/mme_di_client -m gw -b < $tempfile > $resfilea
 


#
# Map result files into arrays
#
mapfile -t tabb < $resfileb
mapfile -t taba < $resfilea
c=0
utotal=0
ubtotal=0
ugtotal=0
dtotal=0
dbtotal=0
dgtotal=0
if [ ${#taba[@]} -eq ${#tabb[@]} ]
then
clear
date
echo -e
while [ $c -lt ${#taba[@]} ]
do
    eval `echo ${tabb[$c]} | sed 's/\([^=]*\)=\([^ ]*\)[ ]*/before["\1"]=\2;/g'`
    eval `echo ${taba[$c]} | sed 's/\([^=]*\)=\([^ ]*\)[ ]*/after["\1"]=\2;/g'`
    # compute bit rates in bps
    urate=`expr ${after["U"]} - ${before["U"]}`
    drate=`expr ${after["D"]} - ${before["D"]}`
    urate=`expr $urate \* 8`
    drate=`expr $drate \* 8`
    utotal=`expr $utotal + $urate`
    dtotal=`expr $dtotal + $drate`
    if [[ ${after["Q"]} == "01"* ]] || [[ ${before["Q"]} == "02"* ]] || [[ ${before["Q"]} == "03"* ]] || [[ ${before["Q"]} == "04"* ]]; then
	gbr=1
	ugtotal=`expr $ugtotal + $urate`
	dgtotal=`expr $dgtotal + $drate`
    else
	gbr=0
	ubtotal=`expr $ubtotal + $urate`
	dbtotal=`expr $dbtotal + $drate`
    fi

    #
    # Ajout de l'IP du SG
    #
    bearerRef=`echo ${taba[$c]} | sed -e 's/^.*=//' | head -1`
    echo "printBearerCtxByRef($bearerRef)" > $tempfile
    /opt/ltebox/bin/mme_di_client -m gw -b < $tempfile > $resfilec
    s1_U_eNBRef=`grep "S1-U eNB ref=" $resfilec | sed -e 's/^.*=//' | head -1`
    echo "printEnbCtxByRef($s1_U_eNBRef)" > $tempfile
    /opt/ltebox/bin/mme_di_client -m gw -b < $tempfile > $resfilec
    eNBIPaddr=`grep "eNB IP addr=" $resfilec | sed -e 's/^.*=//'| head -1 `
    foo="`echo ${taba[$c]}  | sed -e 's/ [^ ]*$//'`"
    
    newline=$foo" "$urate" bps"" "$drate" bps "$eNBIPaddr
    if [ $gbr == 0 ]; then
	echo -e $newline | awk '{ printf("%-17s %s \033[34m%s\033[0m UL_rate \033[31m%12d\033[0m %s  DL_rate             \033[32m%12d\033[0m %s GTP-IP=%s\n", $1, $3, $4, $11, $12, $13, $14, $15); }'
    else
	echo -e $newline | awk '{ printf("%-17s %s \033[35m%s\033[0m UL_rate \033[31m%12d\033[0m %s  DL_rate             \033[32m%12d\033[0m %s GTP-IP=%s\n", $1, $3, $4, $11, $12, $13, $14, $15); }'
    fi
    let "c++"
done
totalgline="$ugtotal"" ""bps"" "$dgtotal" bps"
totalbline="$ubtotal"" ""bps"" "$dbtotal" bps"
totalline="$utotal"" ""bps"" "$dtotal" bps"
echo -e
echo -e $totalgline | awk '{ printf("                         \033[35mTotal UL_GBR_rate \033[0m  \033[31m%12d\033[0m %s  \033[35mTotal DL_GBR_rate \033[0m  \033[32m%12d\033[0m %s\n", $1, $2, $3, $4); }'
echo -e $totalbline | awk '{ printf("                         \033[34mTotal UL_NGBR_rate \033[0m \033[31m%12d\033[0m %s  \033[34mTotal DL_NGBR_rate \033[0m \033[32m%12d\033[0m %s\n", $1, $2, $3, $4); }'
echo -e $totalline  | awk '{ printf("                         Total UL_rate       \033[31m%12d\033[0m %s  Total DL_rate       \033[32m%12d\033[0m %s\n", $1, $2, $3, $4); }'

fi

\rm -f $resfilea
\rm -f $resfileb
\rm -f $resfilec
\rm -f $tempfile

