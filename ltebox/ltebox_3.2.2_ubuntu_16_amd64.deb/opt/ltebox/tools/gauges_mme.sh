#!/bin/sh
/opt/ltebox/bin/mme_di_client -m mash -b < /opt/ltebox/tools/gauges_mme
/opt/ltebox/bin/mme_di_client -m s1ap_c -b < /opt/ltebox/tools/gauges_s1ap
/opt/ltebox/bin/mme_di_client -m m3ap_c -b < /opt/ltebox/tools/gauges_m3ap
/opt/ltebox/bin/mme_di_client -m mash -b < /opt/ltebox/tools/gauges_mbms
