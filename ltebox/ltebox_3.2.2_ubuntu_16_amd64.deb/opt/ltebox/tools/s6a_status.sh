#!/bin/sh
/opt/ltebox/bin/mme_di_client -m mash -b < /opt/ltebox/tools/s6a_status
