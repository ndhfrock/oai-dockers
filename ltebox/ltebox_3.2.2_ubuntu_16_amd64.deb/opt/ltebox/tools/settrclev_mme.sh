#!/bin/sh
tempfile=`mktemp -p /tmp`
echo "setTraceLevel(\"all\", $1)" > $tempfile
/opt/ltebox/bin/mme_di_client -m mash -b < $tempfile
rm -f $tempfile 
